<?php

namespace App\Services;

use AfricasTalking\SDK\AfricasTalking;

class SMSService
{
    protected $sms;

    public function __construct()
    {
        $username = env('AFRICASTALKING_USERNAME');
        $apiKey = env('AFRICASTALKING_API_KEY');

        $AT = new AfricasTalking($username, $apiKey);
        $this->sms = $AT->sms();
    }

    public function sendSMS($message, $recipients)
    {
        try {
            return $this->sms->send([
                'to'      => $recipients,
                'message' => $message,
            ]);
        } catch (\Exception $e) {
            return ['error' => $e->getMessage()];
        }
    }
}

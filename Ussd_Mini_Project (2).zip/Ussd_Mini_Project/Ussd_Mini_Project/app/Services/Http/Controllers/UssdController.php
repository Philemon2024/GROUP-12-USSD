<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\SMSService;

class UssdController extends Controller
{
    public function handle(Request $request)
    {
        $phone = $request->input('phoneNumber');
        $text = $request->input('text');

        // Split user input
        $input = explode("*", $text);

        if (empty($text)) {
            $response = "CON Welcome to Philemon USSD Service\n";
            $response .= "1. Register\n";
            $response .= "2. Exit";
        } else if ($text == "1") {
            // Send SMS
            $sms = new SMSService();
            $sms->sendSMS("Murakoze kwiyandikisha kuri USSD ya Philemon! 📲", $phone);

            $response = "END Registration complete. Check your SMS!";
        } else {
            $response = "END Thank you for using our service.";
        }

        return response($response)->header('Content-Type', 'text/plain');
    }
}
